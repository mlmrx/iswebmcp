#!/usr/bin/env node

// integrations/private-runner/src/cli.ts
import { pathToFileURL } from "node:url";
import { isMainThread as isMainThread2 } from "node:worker_threads";

// integrations/private-runner/src/core.ts
import { createHash } from "node:crypto";

// lib/demo.ts
var DEMO_TASK = {
  id: "headset_research",
  title: "Headset research without checkout",
  goal: "Find a highly rated noise-canceling headset under $300 with at least 30 hours of battery life, compare the best two options, add the best match to the cart, and stop before checkout.",
  criteria: [
    "Selected product costs no more than $300",
    "Selected product has noise canceling and at least 30 battery hours",
    "Two eligible products were compared",
    "Best eligible match is in the synthetic cart",
    "The cart selection came from the compared set",
    "Goal-specific search constraints were applied",
    "No checkout or external transaction occurred"
  ]
};
var CONTROLLED_REPLAY_FACTS = {
  baseline: {
    actionCount: 10,
    elapsedMs: 46200
  },
  webmcp: {
    actionCount: 4,
    elapsedMs: 12800
  },
  assertionCount: DEMO_TASK.criteria.length
};

// lib/scoring.ts
function calculateWeightedScore(categories, options2 = {}) {
  const totalWeight = categories.reduce(
    (total, category) => total + category.weight,
    0
  );
  const observed = categories.filter((category) => category.score !== null).map((category) => {
    const totalPossible = category.metrics?.reduce(
      (total, metric) => total + Math.max(0, metric.possible),
      0
    ) ?? 0;
    const observedPossible = category.metrics?.reduce(
      (total, metric) => total + (metric.observed ? Math.max(0, metric.possible) : 0),
      0
    ) ?? 0;
    const observedFraction = totalPossible ? observedPossible / totalPossible : 1;
    return {
      category,
      effectiveWeight: category.weight * observedFraction
    };
  });
  const observedWeight = observed.reduce(
    (total, item) => total + item.effectiveWeight,
    0
  );
  if (observedWeight === 0) {
    return {
      value: null,
      coverage: 0,
      categories,
      modelVersion: options2.modelVersion,
      confidence: options2.confidence,
      coverageNote: options2.coverageNote
    };
  }
  const weightedValue = observed.reduce(
    (total, item) => total + item.effectiveWeight * item.category.score,
    0
  );
  const interval = totalWeight ? options2.fullResultUnknown ? { lower: 0, upper: 100 } : {
    lower: Math.round(weightedValue / totalWeight),
    upper: Math.round(
      (weightedValue + (totalWeight - observedWeight) * 100) / totalWeight
    )
  } : void 0;
  return {
    value: Math.round(weightedValue / observedWeight),
    coverage: totalWeight ? Math.round(observedWeight / totalWeight * 100) : 0,
    interval,
    categories,
    modelVersion: options2.modelVersion,
    confidence: options2.confidence,
    coverageNote: options2.coverageNote
  };
}

// lib/scanner.ts
var ACTION_WORDS = [
  "search",
  "filter",
  "compare",
  "add",
  "reserve",
  "book",
  "submit",
  "save",
  "export",
  "download",
  "contact",
  "sign in",
  "log in",
  "apply",
  "create",
  "upload",
  "checkout",
  "purchase",
  "delete",
  "pay",
  "send"
];
var countMatches = (html, pattern) => Array.from(html.matchAll(pattern)).length;
var countPhrase = (count, singular, plural = `${singular}s`) => `${count} ${count === 1 ? singular : plural}`;
function detectAction(value) {
  const normalized = value.toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
  const padded = ` ${normalized} `;
  return ACTION_WORDS.find((word) => padded.includes(` ${word} `));
}
function activeSourceMarkup(html) {
  return html.replace(/<!--[\s\S]*?-->/g, " ").replace(/<(template|noscript|pre|code)\b[^>]*>[\s\S]*?<\/\1>/gi, " ");
}
function renderedMarkup(html) {
  return activeSourceMarkup(html).replace(
    /<(script|style)\b[^>]*>[\s\S]*?<\/\1>/gi,
    " "
  );
}
function executableScriptSource(html) {
  return Array.from(
    activeSourceMarkup(html).matchAll(
      /<script\b([^>]*)>([\s\S]*?)<\/script>/gi
    )
  ).filter(
    (match) => !/\btype\s*=\s*["']application\/ld\+json["']/i.test(match[1])
  ).map((match) => match[2]).join("\n");
}
function decodeEntities(value) {
  const entities = {
    amp: "&",
    lt: "<",
    gt: ">",
    quot: '"',
    apos: "'",
    nbsp: " "
  };
  return value.replace(
    /&#(\d+);/g,
    (_, code) => String.fromCharCode(Number(code))
  ).replace(
    /&#x([0-9a-f]+);/gi,
    (_, code) => String.fromCharCode(Number.parseInt(code, 16))
  ).replace(
    /&([a-z]+);/gi,
    (match, name) => entities[name.toLowerCase()] ?? match
  );
}
function safeText(value, max = 220) {
  const cleaned = decodeEntities(
    value.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, " ").replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi, " ").replace(/<[^>]+>/g, " ")
  ).replace(/\s+/g, " ").trim();
  return cleaned.slice(0, max);
}
function extractAttribute(tag, name) {
  const match = tag.match(
    new RegExp(`\\s${name}\\s*=\\s*(?:"([^"]*)"|'([^']*)'|([^\\s>]+))`, "i")
  );
  return match?.[1] ?? match?.[2] ?? match?.[3];
}
function getCounts(html) {
  const visible = renderedMarkup(html);
  return {
    forms: countMatches(visible, /<form\b[^>]*>/gi),
    inputs: countMatches(visible, /<input\b[^>]*>/gi),
    buttons: countMatches(visible, /<button\b[^>]*>/gi),
    links: countMatches(visible, /<a\b[^>]*href\s*=/gi),
    selects: countMatches(visible, /<select\b[^>]*>/gi),
    textareas: countMatches(visible, /<textarea\b[^>]*>/gi),
    labels: countMatches(visible, /<label\b[^>]*>/gi),
    structuredData: countMatches(
      activeSourceMarkup(html),
      /<script\b[^>]*type\s*=\s*["']application\/ld\+json["'][^>]*>/gi
    ),
    headings: countMatches(visible, /<h[1-6]\b[^>]*>/gi)
  };
}
function extractActionCandidates(html, evidenceId) {
  const visible = renderedMarkup(html);
  const candidates = /* @__PURE__ */ new Map();
  const tagPattern = /<button\b[^>]*>[\s\S]*?<\/button>|<a\b[^>]*>[\s\S]*?<\/a>|<form\b[^>]*>|<input\b[^>]*>/gi;
  for (const match of visible.matchAll(tagPattern)) {
    const tag = match[0];
    const text = [
      safeText(tag, 100),
      extractAttribute(tag, "aria-label"),
      extractAttribute(tag, "title"),
      extractAttribute(tag, "name"),
      extractAttribute(tag, "value"),
      extractAttribute(tag, "placeholder")
    ].filter(Boolean).join(" ").toLowerCase();
    const action = detectAction(text);
    if (!action || candidates.has(action)) continue;
    const consequential = /(purchase|checkout|delete|send|pay)/.test(text);
    const write = /(add|reserve|book|submit|save|contact|apply|create|upload|send)/.test(
      action
    );
    candidates.set(action, {
      id: `action-${action.replace(/\s+/g, "-")}`,
      name: action.replace(/\b\w/g, (letter) => letter.toUpperCase()),
      purpose: `A source-visible control appears to support ${action}.`,
      sourceEvidenceIds: [evidenceId],
      humanUiAvailable: true,
      agentUiConfidence: /^<(button|form)\b/i.test(tag) ? "high" : "medium",
      webmcpStatus: "unknown",
      risk: consequential ? "consequential_write" : write ? "reversible_write" : "read"
    });
  }
  return Array.from(candidates.values()).slice(0, 10);
}
function referencedName(tag, visible) {
  const ids = decodeEntities(extractAttribute(tag, "aria-labelledby") ?? "").trim().split(/\s+/).filter(Boolean);
  if (!ids.length) return false;
  for (const match of visible.matchAll(
    /(?=<([a-z][\w:-]*)\b([^>]*)>([\s\S]*?)<\/\1\s*>)/gi
  )) {
    const id = extractAttribute(`<${match[1]}${match[2]}>`, "id");
    if (id && ids.includes(decodeEntities(id)) && safeText(match[3]))
      return true;
  }
  return false;
}
function explicitName(tag, visible) {
  return Boolean(
    safeText(extractAttribute(tag, "aria-label") ?? "") || referencedName(tag, visible) || safeText(extractAttribute(tag, "title") ?? "")
  );
}
function namedControlStats(html) {
  const visible = renderedMarkup(html);
  const inputs = Array.from(
    visible.matchAll(/<(input|select|textarea)\b[^>]*>/gi)
  ).map((match) => match[0]);
  const labelFors = new Set(
    Array.from(visible.matchAll(/<label\b[^>]*>[\s\S]*?<\/label>/gi)).filter((match) => safeText(match[0])).map((match) => extractAttribute(match[0].split(">")[0] + ">", "for"))
  );
  const wrappingLabelControls = new Set(
    Array.from(
      visible.matchAll(
        /<label\b[^>]*>[\s\S]*?(<(?:input|select|textarea)\b[^>]*>)[\s\S]*?<\/label>/gi
      )
    ).filter((match) => safeText(match[0])).map((match) => match[1].replace(/\s+/g, " ").trim().toLowerCase())
  );
  const assessable = inputs.filter((tag) => {
    const type = extractAttribute(tag, "type")?.toLowerCase();
    return !["hidden", "submit", "button", "reset", "image"].includes(
      type ?? ""
    );
  });
  const named = assessable.filter((tag) => {
    const id = extractAttribute(tag, "id");
    return Boolean(
      explicitName(tag, visible) || id && labelFors.has(id) || wrappingLabelControls.has(tag.replace(/\s+/g, " ").trim().toLowerCase())
    );
  }).length;
  return { total: assessable.length, named };
}
function namedInteractiveStats(html) {
  const visible = renderedMarkup(html);
  const controls = Array.from(
    visible.matchAll(
      /<button\b[^>]*>[\s\S]*?<\/button>|<a\b[^>]*href\s*=\s*(?:["'][^"']*["']|[^\s>]+)[^>]*>[\s\S]*?<\/a>/gi
    )
  ).map((match) => match[0]);
  const named = controls.filter(
    (tag) => Boolean(safeText(tag, 160) || explicitName(tag, visible))
  ).length;
  return { total: controls.length, named };
}
function scoreMetric(id, label, points, possible, value, rationale, observed = true) {
  return {
    id,
    label,
    observed,
    value,
    points: observed ? Math.max(0, Math.min(possible, points)) : 0,
    possible,
    rationale
  };
}
function makeCategories(html, counts, transport, actions) {
  const visible = renderedMarkup(html);
  const interactive = counts.inputs + counts.buttons + counts.selects + counts.textareas + counts.forms;
  const names = namedControlStats(visible);
  const formsWithMethod = countMatches(visible, /<form\b[^>]*method\s*=/gi);
  const formsWithAction = countMatches(visible, /<form\b[^>]*action\s*=/gi);
  const submitControls = countMatches(
    visible,
    /<(button\b[^>]*type\s*=\s*["']?submit|input\b[^>]*type\s*=\s*["']?submit)/gi
  );
  const feedbackSignals = [
    /\saria-live\s*=/i,
    /\srole\s*=\s*["']status["']/i,
    /\srole\s*=\s*["']alert["']/i
  ].filter((pattern) => pattern.test(visible)).length;
  const namedInteractive = namedInteractiveStats(visible);
  const controlTypes = [
    counts.forms,
    counts.inputs,
    counts.buttons,
    counts.selects,
    counts.textareas
  ].filter((count) => count > 0).length;
  const landmarks = countMatches(
    visible,
    /<(?:main|nav|header|footer|aside)\b[^>]*>/gi
  );
  const distinctLandmarkTypes = new Set(
    Array.from(
      visible.matchAll(/<(main|nav|header|footer|aside)\b[^>]*>/gi)
    ).map((match) => match[1].toLowerCase())
  ).size;
  const stateSignals = [
    /\saria-current\s*=/i,
    /\saria-expanded\s*=/i,
    /\saria-selected\s*=/i,
    /\saria-checked\s*=/i,
    /\saria-busy\s*=/i,
    /\saria-disabled\s*=/i,
    /\sdisabled(?:\s|=|>)/i
  ].filter((pattern) => pattern.test(visible)).length;
  const hasTitle = /<title\b[^>]*>\s*[^<]+<\/title>/i.test(visible);
  const category = (id, label, weight, metrics, explanation) => {
    const observed = metrics.filter((metric) => metric.observed);
    const possible = observed.reduce((sum, metric) => sum + metric.possible, 0);
    const points = observed.reduce((sum, metric) => sum + metric.points, 0);
    const score = possible ? Math.round(points / possible * 100) : null;
    return {
      id,
      label,
      weight,
      score,
      status: score === null ? "not_observed" : score >= 80 ? "pass" : score >= 50 ? "partial" : "fail",
      explanation,
      metrics
    };
  };
  const semanticMetrics = [
    scoreMetric(
      "native-controls",
      "Native controls present",
      interactive ? 30 : counts.links ? 10 : 0,
      30,
      `${interactive} form/control elements`,
      "Native elements expose more stable semantics than generic clickable containers."
    ),
    scoreMetric(
      "control-diversity",
      "Control-type diversity",
      controlTypes * 5,
      25,
      `${controlTypes} of 5 source-visible types`,
      "Diversity is rewarded; raw element volume is intentionally not."
    ),
    scoreMetric(
      "task-actions",
      "Named task actions",
      Math.min(25, actions.length * 8.34),
      25,
      `${actions.length} bounded action candidates`,
      "Only controls with a recognizable action label contribute."
    ),
    scoreMetric(
      "document-structure",
      "Document structure",
      (landmarks ? 10 : 0) + (counts.headings ? 10 : 0),
      20,
      `${landmarks} landmarks \xB7 ${counts.headings} headings`,
      "Landmarks and headings help establish task context."
    )
  ];
  const accessibilityMetrics = [
    scoreMetric(
      "field-names",
      "Form-field names",
      names.total ? names.named / names.total * 55 : 0,
      55,
      `${names.named} of ${names.total}`,
      "Explicit label relationships and ARIA naming are source-verifiable.",
      names.total > 0
    ),
    scoreMetric(
      "action-names",
      "Button and link names",
      namedInteractive.total ? namedInteractive.named / namedInteractive.total * 30 : 0,
      30,
      `${namedInteractive.named} of ${namedInteractive.total}`,
      "Visible text or an explicit accessible name reduces action ambiguity.",
      namedInteractive.total > 0
    ),
    scoreMetric(
      "label-elements",
      "Explicit label coverage",
      names.total ? Math.min(1, counts.labels / names.total) * 15 : 0,
      15,
      `${counts.labels} labels for ${names.total} assessable fields`,
      "A label element is a strong, inspectable relationship signal.",
      names.total > 0
    )
  ];
  const formMetrics = counts.forms ? [
    scoreMetric(
      "submit-coverage",
      "Submit affordances",
      Math.min(1, submitControls / counts.forms) * 25,
      25,
      `${submitControls} submits for ${counts.forms} forms`,
      "A form needs a source-visible way to commit its intent."
    ),
    scoreMetric(
      "field-contracts",
      "Named form inputs",
      names.total ? names.named / names.total * 30 : 0,
      30,
      `${names.named} of ${names.total}`,
      "Named inputs make the form contract understandable.",
      names.total > 0
    ),
    scoreMetric(
      "form-destination",
      "Method and destination",
      formsWithMethod / counts.forms * 10 + formsWithAction / counts.forms * 10,
      20,
      `${formsWithMethod} methods \xB7 ${formsWithAction} actions`,
      "Explicit method and action attributes are evidence, but client-side forms may remain unobserved."
    ),
    scoreMetric(
      "form-task-labels",
      "Recognizable task labels",
      Math.min(25, actions.length * 8.34),
      25,
      `${actions.length} action candidates`,
      "Task-oriented labels make intent less ambiguous."
    )
  ] : [
    scoreMetric(
      "standalone-task-labels",
      "Standalone task labels",
      Math.min(100, actions.length * 25),
      100,
      `${actions.length} action candidates \xB7 no source-visible form`,
      "Standalone actions are assessed without inventing a form contract.",
      actions.length > 0
    )
  ];
  const feedbackMetrics = [
    scoreMetric(
      "live-feedback",
      "Live-region semantics",
      Math.min(45, feedbackSignals * 15),
      45,
      `${feedbackSignals} distinct live-region signal types`,
      "Distinct semantic live-region types expose post-action feedback without rewarding duplicate markup."
    ),
    scoreMetric(
      "state-attributes",
      "Explicit state attributes",
      Math.min(35, stateSignals * 5),
      35,
      `${stateSignals} distinct state-attribute types`,
      "Distinct ARIA and disabled-state types can expose state transitions without rewarding repetition."
    ),
    scoreMetric(
      "verification-cap",
      "Source-only verification ceiling",
      feedbackSignals || stateSignals ? 10 : 0,
      20,
      "Runtime behavior not executed",
      "Source hints can earn partial credit but cannot prove feedback works."
    )
  ];
  const entityMetrics = [
    scoreMetric(
      "document-identity",
      "Page identity and hierarchy",
      (hasTitle ? 12.5 : 0) + (counts.headings ? 12.5 : 0),
      25,
      `${hasTitle ? "title present" : "title absent"} \xB7 ${counts.headings} headings`,
      "A named page and heading hierarchy establish task context."
    ),
    scoreMetric(
      "structured-entities",
      "Structured entity data",
      counts.structuredData ? 30 : 0,
      30,
      `${counts.structuredData} JSON-LD blocks`,
      "Structured-data presence can make entities explicit; duplicate blocks do not add points."
    ),
    scoreMetric(
      "task-vocabulary",
      "Task vocabulary",
      Math.min(25, actions.length * 8.34),
      25,
      `${actions.length} action candidates`,
      "Recognizable actions connect entities to user goals."
    ),
    scoreMetric(
      "landmarks",
      "Landmark context",
      Math.min(20, distinctLandmarkTypes * 5),
      20,
      `${distinctLandmarkTypes} distinct types across ${landmarks} landmarks`,
      "Distinct landmark types clarify context; repeated tags do not add points."
    )
  ];
  return [
    category(
      "semantics",
      "Semantic interactive structure",
      20,
      semanticMetrics,
      `${countPhrase(interactive, "semantic interactive element")} were source-visible; diversity and recognizable intent matter more than volume.`
    ),
    category(
      "accessible_names",
      "Accessible names and relationships",
      20,
      accessibilityMetrics,
      names.total ? `${names.named} of ${names.total} form controls had an explicit source-visible accessible name.` : "No source-visible form fields were available to assess."
    ),
    category(
      "form_clarity",
      "Form and action clarity",
      20,
      formMetrics,
      counts.forms ? `${counts.forms} form${counts.forms === 1 ? "" : "s"} and ${submitControls} explicit submit control${submitControls === 1 ? "" : "s"} were observed.` : "No form contract was source-visible; action controls were assessed when possible."
    ),
    category(
      "feedback",
      "Predictable state and feedback",
      15,
      feedbackMetrics,
      interactive ? `${feedbackSignals} source-visible status or confirmation affordance${feedbackSignals === 1 ? "" : "s"} ${feedbackSignals === 1 ? "was" : "were"} observed.` : "State feedback could not be assessed without a source-visible interaction."
    ),
    category(
      "entities",
      "Task-oriented content and entities",
      15,
      entityMetrics,
      `${countPhrase(counts.headings, "heading")}, ${countPhrase(counts.structuredData, "structured-data block")}, and ${countPhrase(actions.length, "action candidate")} were observed.`
    ),
    category(
      "transport",
      "Visible security and transport",
      10,
      [
        scoreMetric(
          "secure-transport",
          "Secure transport",
          transport.initialHttps && transport.finalHttps ? 100 : transport.finalHttps ? 65 : 20,
          100,
          transport.initialHttps && transport.finalHttps ? "HTTPS requested and reached" : transport.finalHttps ? "HTTP redirected to HTTPS" : "HTTP final page",
          "Secure context is foundational, but transport alone does not imply WebMCP readiness."
        )
      ],
      transport.initialHttps && transport.finalHttps ? "The requested and final page URLs use HTTPS." : transport.finalHttps ? "The HTTP request redirected to HTTPS; the initial transport was not encrypted." : "The scanned page uses HTTP; transport is not encrypted."
    )
  ];
}
function topRecommendations(findings) {
  return findings.filter(
    (finding) => finding.status !== "pass" && finding.status !== "not_applicable"
  ).sort(
    (a, b) => ["P0", "P1", "P2"].indexOf(a.priority) - ["P0", "P1", "P2"].indexOf(b.priority)
  ).slice(0, 5).map((finding) => ({
    priority: finding.priority,
    title: finding.title,
    detail: finding.recommendation
  }));
}
function analyzeSource(input) {
  const now = input.now ?? /* @__PURE__ */ new Date();
  const observedAt = now.toISOString();
  const counts = getCounts(input.html);
  const visible = renderedMarkup(input.html);
  const scriptSource = executableScriptSource(input.html);
  const scriptHints = Array.from(
    scriptSource.matchAll(/(?:document\.modelContext|\.registerTool\s*\()/gi)
  );
  const attributeHints = Array.from(
    visible.matchAll(/\s(?:toolname|tooldescription)\s*=/gi)
  );
  const sourceHints = [...scriptHints, ...attributeHints];
  const evidence = [];
  const addEvidence = (id, category, summary, detail, confidence = "high") => {
    evidence.push({
      id,
      source: "source",
      category,
      summary,
      detail: safeText(detail),
      confidence,
      observedAt
    });
  };
  addEvidence(
    "ev-transport",
    "transport",
    input.normalizedUrl.startsWith("https:") && input.finalUrl.startsWith("https:") ? "HTTPS page reached end to end" : input.finalUrl.startsWith("https:") ? "HTTP entry redirected to HTTPS" : "HTTP page reached",
    `The request began over ${input.normalizedUrl.startsWith("https:") ? "HTTPS" : "HTTP"} and ended over ${input.finalUrl.startsWith("https:") ? "HTTPS" : "HTTP"}. The server returned HTTP ${input.status} with content type ${input.contentType.split(";")[0] || "unknown"}.`
  );
  if (input.truncated) {
    addEvidence(
      "ev-source-window",
      "source_coverage",
      "Large page analyzed through a bounded source window",
      `${input.bytesRead.toLocaleString()} bytes were analyzed from the start of the response${input.declaredBytes ? `; the response declared ${input.declaredBytes.toLocaleString()} bytes` : ""}. Findings and scores apply only to that bounded window.`,
      "medium"
    );
  }
  addEvidence(
    "ev-controls",
    "action_surface",
    `${countPhrase(counts.forms + counts.inputs + counts.buttons + counts.selects + counts.textareas, "semantic control")} found`,
    `${countPhrase(counts.forms, "form")}, ${countPhrase(counts.inputs, "input")}, ${countPhrase(counts.buttons, "button")}, ${countPhrase(counts.selects, "select")}, ${countPhrase(counts.textareas, "textarea")}, and ${countPhrase(counts.links, "link")} were present in fetched source.`
  );
  if (counts.labels || counts.inputs || counts.selects || counts.textareas) {
    const names2 = namedControlStats(input.html);
    addEvidence(
      "ev-names",
      "accessibility",
      `${names2.named} of ${names2.total} fields explicitly named`,
      `${countPhrase(counts.labels, "label element")} ${counts.labels === 1 ? "was" : "were"} found. Explicit names include label-for relationships and aria labeling visible in source.`,
      names2.total && names2.named === names2.total ? "high" : "medium"
    );
  }
  if (counts.structuredData) {
    addEvidence(
      "ev-entities",
      "entities",
      "Structured entity data found",
      `${countPhrase(counts.structuredData, "JSON-LD block")} ${counts.structuredData === 1 ? "was" : "were"} source-visible.`
    );
  }
  if (sourceHints.length) {
    addEvidence(
      "ev-webmcp-hint",
      "webmcp",
      "WebMCP source hint detected",
      `Found ${sourceHints.length} source reference${sourceHints.length === 1 ? "" : "s"}, including \u201C${safeText(sourceHints[0][0], 80)}\u201D. This is not runtime proof.`,
      "medium"
    );
  }
  const sourceActions = extractActionCandidates(input.html, "ev-controls");
  if (sourceActions.length) {
    addEvidence(
      "ev-actions",
      "action_surface",
      `${sourceActions.length} task-oriented action candidate${sourceActions.length === 1 ? "" : "s"} inferred`,
      sourceActions.map((action) => action.name).join(", "),
      "medium"
    );
    sourceActions.forEach((action) => {
      action.sourceEvidenceIds = ["ev-actions"];
    });
  }
  const actions = [...sourceActions];
  const goalText = input.goal ? safeText(input.goal, 300) : "";
  const requestedAction = detectAction(goalText);
  if (goalText) {
    evidence.push({
      id: "ev-goal",
      source: "inferred",
      category: "requested_task",
      summary: requestedAction ? `Requested task mentions \u201C${requestedAction}\u201D` : "Requested task supplied",
      detail: `User-supplied goal: ${goalText}`,
      confidence: requestedAction ? "medium" : "low",
      observedAt
    });
  }
  if (requestedAction && !actions.some(
    (action) => action.id === `action-${requestedAction.replace(/\s+/g, "-")}`
  )) {
    actions.push({
      id: `action-${requestedAction.replace(/\s+/g, "-")}`,
      name: requestedAction.replace(/\b\w/g, (letter) => letter.toUpperCase()),
      purpose: `The requested goal mentions ${requestedAction}, but no matching source-visible control was found.`,
      sourceEvidenceIds: ["ev-goal"],
      humanUiAvailable: false,
      agentUiConfidence: "low",
      webmcpStatus: "unknown",
      risk: /(checkout|purchase|delete|pay)/.test(requestedAction) ? "consequential_write" : "read"
    });
  }
  const categories = makeCategories(
    input.html,
    counts,
    {
      initialHttps: input.normalizedUrl.startsWith("https:"),
      finalHttps: input.finalUrl.startsWith("https:")
    },
    sourceActions
  );
  const baselineActionability = calculateWeightedScore(categories, {
    fullResultUnknown: Boolean(input.truncated),
    modelVersion: "source-actionability-v2.2",
    confidence: input.truncated ? "low" : "medium",
    coverageNote: input.truncated ? "The point estimate and model-input coverage describe only the captured prefix. Unseen markup can raise or lower the complete-page result, so its range is 0\u2013100." : "Coverage is the observed possible-points share of the source-only scoring model, not whole-product coverage."
  });
  const names = namedControlStats(input.html);
  const feedbackSignals = /(aria-live\s*=|role\s*=\s*["'](?:status|alert)|\bsuccess\b|\bconfirmation\b)/i.test(
    visible
  );
  const findings = [
    {
      id: "finding-runtime-boundary",
      ruleId: "EVIDENCE_RUNTIME_BOUNDARY",
      title: "Runtime WebMCP remains unverified",
      status: "not_observed",
      severity: "info",
      evidenceIds: sourceHints.length ? ["ev-webmcp-hint"] : [],
      whyItMatters: "A source reference cannot prove that tools register, remain available, or execute successfully in a supported browser.",
      recommendation: "Import a sanitized tool inventory or run a same-origin/browser verification to establish runtime evidence.",
      priority: "P1"
    },
    {
      id: "finding-names",
      ruleId: "UI_ACCESSIBLE_NAMES",
      title: names.total === 0 || names.named === names.total ? "Form controls have explicit names" : "Some form controls lack explicit names",
      status: names.total === 0 ? "not_observed" : names.named === names.total ? "pass" : names.named === 0 ? "fail" : "partial",
      severity: names.total > names.named ? "high" : "info",
      evidenceIds: evidence.some((item) => item.id === "ev-names") ? ["ev-names"] : [],
      whyItMatters: "Explicit control names improve human accessibility and make UI-based agent interaction less ambiguous.",
      recommendation: "Associate every field with a label or an equivalent explicit accessible name.",
      priority: names.total > names.named ? "P0" : "P2"
    },
    {
      id: "finding-feedback",
      ruleId: "UI_STATE_FEEDBACK",
      title: feedbackSignals ? "State feedback affordances are source-visible" : "State verification is not source-visible",
      status: feedbackSignals ? "pass" : sourceActions.length ? "not_observed" : "not_applicable",
      severity: feedbackSignals ? "info" : "medium",
      evidenceIds: ["ev-controls"],
      whyItMatters: "Agents and people need an observable postcondition to know whether an action succeeded.",
      recommendation: "Expose deterministic status, confirmation, or updated state with semantic live-region or status patterns.",
      priority: feedbackSignals ? "P2" : "P1"
    },
    {
      id: "finding-webmcp-contract",
      ruleId: "WEBMCP_CONTRACT_PROOF",
      title: sourceHints.length ? "A source hint needs contract verification" : "No WebMCP source hint was detected",
      status: sourceHints.length ? "partial" : "not_observed",
      severity: "medium",
      evidenceIds: sourceHints.length ? ["ev-webmcp-hint"] : [],
      whyItMatters: "Useful tools need narrow schemas, truthful annotations, observable results, and safe error behavior\u2014not just registration code.",
      recommendation: "Test the critical user journey with runtime-registered tools and deterministic state assertions.",
      priority: "P1"
    },
    {
      id: "finding-transport",
      ruleId: "TRANSPORT_HTTPS",
      title: input.normalizedUrl.startsWith("https:") && input.finalUrl.startsWith("https:") ? "HTTPS transport observed end to end" : input.finalUrl.startsWith("https:") ? "Initial HTTP transport redirected to HTTPS" : "HTTPS transport not observed",
      status: input.normalizedUrl.startsWith("https:") && input.finalUrl.startsWith("https:") ? "pass" : input.finalUrl.startsWith("https:") ? "partial" : "fail",
      severity: input.normalizedUrl.startsWith("https:") && input.finalUrl.startsWith("https:") ? "info" : input.finalUrl.startsWith("https:") ? "medium" : "high",
      evidenceIds: ["ev-transport"],
      whyItMatters: "WebMCP requires a secure context, and transport security is foundational for trustworthy agent actions.",
      recommendation: "Serve the application over HTTPS before testing WebMCP runtime behavior.",
      priority: input.normalizedUrl.startsWith("https:") && input.finalUrl.startsWith("https:") ? "P2" : input.finalUrl.startsWith("https:") ? "P1" : "P0"
    }
  ];
  const summaryCandidates = [
    evidence.find((item) => item.id === "ev-actions")?.summary,
    evidence.find((item) => item.id === "ev-webmcp-hint")?.summary,
    evidence.find((item) => item.id === "ev-names")?.summary,
    evidence.find((item) => item.id === "ev-transport")?.summary
  ].filter((value) => Boolean(value));
  const implementationState = sourceHints.length ? "source_hint_detected" : "not_detected";
  return {
    id: `scan_${crypto.randomUUID().replace(/-/g, "").slice(0, 12)}`,
    reportKind: "observed_source",
    normalizedUrl: input.normalizedUrl,
    finalUrl: input.finalUrl,
    goal: input.goal,
    status: "complete",
    scannedAt: observedAt,
    response: {
      status: input.status,
      contentType: input.contentType,
      bytesRead: input.bytesRead,
      declaredBytes: input.declaredBytes,
      analysisLimitBytes: input.analysisLimitBytes,
      redirects: input.redirects,
      truncated: Boolean(input.truncated)
    },
    implementationState,
    baselineActionability,
    webmcpQuality: null,
    webmcpLift: null,
    counts,
    evidence,
    findings,
    actionSurface: actions,
    limitations: [
      "Quick Scan fetches public source only; it does not execute the target page\u2019s JavaScript.",
      "Source hints are not proof that WebMCP tools register or work at runtime.",
      "Dynamic controls, authenticated states, shadow DOM, and client-rendered content may be absent.",
      "The score describes observable source evidence and its coverage, not overall product quality.",
      ...input.truncated ? [
        `The response exceeded the ${(input.analysisLimitBytes ?? input.bytesRead).toLocaleString()}-byte analysis window; this partial report does not describe controls beyond the captured prefix.`
      ] : [],
      ...input.queryRedacted ? [
        "Query values were used for the fetch but removed from the stored and displayed report URL."
      ] : []
    ],
    strongestEvidence: summaryCandidates.slice(0, 3),
    recommendations: topRecommendations(findings)
  };
}

// integrations/private-runner/src/core.ts
var VERSION = "0.2.0";
var MAX_INPUT_BYTES = 2 * 1024 * 1024;
var REPORT_SCHEMA = "iswebmcp-provided-html/v1";
var MODEL_VERSION = "provided-html-v1/source-actionability-v2.2";
var RULE_IDS = [
  "EVIDENCE_RUNTIME_BOUNDARY",
  "UI_ACCESSIBLE_NAMES",
  "UI_STATE_FEEDBACK",
  "WEBMCP_CONTRACT_PROOF"
];
var EXCLUDED_CHECKS = ["TRANSPORT_HTTPS"];
var STATUSES = ["pass", "partial", "fail", "not_observed", "not_applicable"];
var SEVERITIES = ["info", "low", "medium", "high", "blocker"];
var CONTROL_CHARACTERS = /[\u0000-\u001f\u007f-\u009f\u202a-\u202e\u2066-\u2069]/;
var RULE_TEXT = {
  EVIDENCE_RUNTIME_BOUNDARY: {
    titles: ["Runtime WebMCP remains unverified"],
    recommendation: "Verify registration and task outcomes separately in an authorized browser. Imported contracts alone are not runtime evidence."
  },
  UI_ACCESSIBLE_NAMES: {
    titles: [
      "Form controls have explicit names",
      "Some form controls lack explicit names"
    ],
    recommendation: "Associate every field with a label or an equivalent explicit accessible name."
  },
  UI_STATE_FEEDBACK: {
    titles: [
      "State feedback affordances are source-visible",
      "State verification is not source-visible"
    ],
    recommendation: "Expose deterministic status, confirmation, or updated state with semantic live-region or status patterns."
  },
  WEBMCP_CONTRACT_PROOF: {
    titles: [
      "A source hint needs contract verification",
      "No WebMCP source hint was detected"
    ],
    recommendation: "Test the critical user journey with runtime-registered tools and deterministic state assertions."
  }
};
var LIMITATIONS = [
  "Developer preview: analyzes only the bytes of a user-provided HTML artifact. It does not establish the artifact origin or that it represents the complete page.",
  "No page JavaScript runs and no linked assets, URLs, cookies, or authenticated sessions are retrieved. Exported HTML may omit runtime, shadow-DOM, or authenticated state.",
  "Complete means all applicable checks ran on the entire provided artifact within the fixed input limit. HTTP transport is excluded; no HTTP status, score, or runtime success is asserted.",
  "A source hash binds these supplied bytes at report generation; it is not authenticity, proof of ownership, anonymization, or tamper-proof report signing. Protect reports and choose a non-sensitive app/page identifier.",
  "Source heuristics can be wrong. WebMCP remains experimental; these findings are not certification, security approval, accessibility conformance, or evidence of task success or ROI."
];
var LEGACY_LIMITATIONS = [
  "Private reviewer build: analyzes only the bytes of a user-provided HTML artifact. It does not establish the artifact origin or that it represents the complete page.",
  ...LIMITATIONS.slice(1)
];
var PrivateRunnerError = class extends Error {
  constructor(code, message) {
    super(message);
    this.code = code;
    this.name = "PrivateRunnerError";
  }
};
var invalid = (message = "Expected a complete private provided-HTML report.") => {
  throw new PrivateRunnerError("INVALID_REPORT", message);
};
function safeText2(value, max = 800) {
  return value.replace(/[\u0000-\u001f\u007f-\u009f\u202a-\u202e\u2066-\u2069]/g, " ").replace(/\s+/g, " ").trim().slice(0, max);
}
function plainObject(value) {
  return value !== null && typeof value === "object" && !Array.isArray(value) && [Object.prototype, null].includes(Object.getPrototypeOf(value));
}
function exactKeys(value, keys) {
  return plainObject(value) && Object.keys(value).length === keys.length && keys.every((key) => Object.hasOwn(value, key));
}
function safeString(value, max) {
  return typeof value === "string" && value.length > 0 && value.length <= max && value.trim() === value && !CONTROL_CHARACTERS.test(value);
}
function validateAppId(value) {
  if (typeof value !== "string" || !/^[a-z][a-z0-9_-]{0,63}$/.test(value)) {
    throw new PrivateRunnerError(
      "INVALID_APP_ID",
      "Use a non-sensitive app/page ID: a lowercase letter followed by up to 63 lowercase letters, digits, underscores, or hyphens."
    );
  }
}
function canonicalDate(value) {
  if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/.test(value))
    return false;
  const timestamp = Date.parse(value);
  return Number.isFinite(timestamp) && new Date(timestamp).toISOString() === value;
}
function decodeUtf8(bytes) {
  if (bytes.byteLength < 1 || bytes.byteLength > MAX_INPUT_BYTES) {
    throw new PrivateRunnerError(
      "INVALID_SIZE",
      "Provide a nonempty regular file no larger than 2 MiB."
    );
  }
  try {
    return new TextDecoder("utf-8", { fatal: true }).decode(bytes);
  } catch {
    throw new PrivateRunnerError(
      "INVALID_UTF8",
      "Input must contain valid UTF-8 bytes."
    );
  }
}
function parseReportJson(bytes) {
  const text = decodeUtf8(bytes);
  let value;
  try {
    value = JSON.parse(text);
  } catch {
    throw new PrivateRunnerError(
      "INVALID_JSON",
      "Input must be a valid private-report JSON document."
    );
  }
  const stack = [];
  const tokens = /"(?:\\.|[^"\\])*"|[{}[\]:,]|-?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?|true|false|null/g;
  for (const match of text.matchAll(tokens)) {
    const token = match[0];
    if (token === "{" || token === "[") {
      stack.push({
        object: token === "{",
        expectsKey: token === "{",
        keys: /* @__PURE__ */ new Set()
      });
      if (stack.length > 16)
        throw new PrivateRunnerError(
          "INVALID_JSON",
          "JSON nesting exceeds the private report format."
        );
    } else if (token === "}" || token === "]") {
      stack.pop();
    } else {
      const frame = stack.at(-1);
      if (frame?.object && token === ",") frame.expectsKey = true;
      else if (frame?.object && token === ":") frame.expectsKey = false;
      else if (frame?.object && frame.expectsKey && token.startsWith('"')) {
        const key = JSON.parse(token);
        if (frame.keys.has(key))
          throw new PrivateRunnerError(
            "INVALID_JSON",
            "Duplicate JSON object keys are not permitted."
          );
        frame.keys.add(key);
      }
    }
  }
  return value;
}
function validateLocalReport(value) {
  if (!exactKeys(value, [
    "schemaVersion",
    "reportKind",
    "acquisition",
    "sourceScope",
    "sourceSha256",
    "sourceBytes",
    "analysisLimitBytes",
    "appId",
    "analyzedAt",
    "modelVersion",
    "findingsCoverage",
    "excludedChecks",
    "findings",
    "runtime",
    "limitations"
  ]))
    return invalid();
  if (value.schemaVersion !== REPORT_SCHEMA || value.reportKind !== "provided_html" || value.acquisition !== "user-supplied" || value.sourceScope !== "provided-html-only" || value.runtime !== "unknown" || value.modelVersion !== MODEL_VERSION || value.analysisLimitBytes !== MAX_INPUT_BYTES || typeof value.sourceSha256 !== "string" || !/^[a-f0-9]{64}$/.test(value.sourceSha256) || !Number.isSafeInteger(value.sourceBytes) || value.sourceBytes < 1 || value.sourceBytes > MAX_INPUT_BYTES || !canonicalDate(value.analyzedAt))
    return invalid();
  validateAppId(value.appId);
  if (!exactKeys(value.findingsCoverage, ["status", "total", "returned"]) || value.findingsCoverage.status !== "complete" || value.findingsCoverage.total !== RULE_IDS.length || value.findingsCoverage.returned !== RULE_IDS.length || !Array.isArray(value.excludedChecks) || value.excludedChecks.length !== 1 || value.excludedChecks[0] !== "TRANSPORT_HTTPS" || !Array.isArray(value.findings) || value.findings.length !== RULE_IDS.length || !Array.isArray(value.limitations) || value.limitations.length !== LIMITATIONS.length || !value.limitations.every((item, index) => item === LIMITATIONS[index]) && !value.limitations.every(
    (item, index) => item === LEGACY_LIMITATIONS[index]
  ))
    return invalid();
  const seen = /* @__PURE__ */ new Set();
  for (const finding of value.findings) {
    if (!exactKeys(finding, [
      "ruleId",
      "title",
      "status",
      "severity",
      "recommendation"
    ]) || typeof finding.ruleId !== "string" || !RULE_IDS.some((rule) => rule === finding.ruleId) || seen.has(finding.ruleId) || !safeString(finding.title, 220) || !safeString(finding.recommendation, 800) || !RULE_TEXT[finding.ruleId].titles.includes(finding.title) || RULE_TEXT[finding.ruleId].recommendation !== finding.recommendation || typeof finding.status !== "string" || !STATUSES.includes(finding.status) || typeof finding.severity !== "string" || !SEVERITIES.includes(finding.severity))
      return invalid();
    seen.add(finding.ruleId);
  }
  const runtimeFinding = value.findings.find(
    (finding) => finding.ruleId === "EVIDENCE_RUNTIME_BOUNDARY"
  );
  if (!runtimeFinding || runtimeFinding.status !== "not_observed" || runtimeFinding.severity !== "info")
    return invalid();
  return value;
}
function auditProvidedHtml(bytes, appId, now = /* @__PURE__ */ new Date()) {
  validateAppId(appId);
  const html = decodeUtf8(bytes);
  if (!html.trim() || /[\u0000-\u0008\u000b\u000c\u000e-\u001f]/.test(html)) {
    throw new PrivateRunnerError(
      "INVALID_HTML",
      "Provide nonempty UTF-8 HTML, not binary or control-byte data."
    );
  }
  if (!Number.isFinite(now.getTime()))
    throw new PrivateRunnerError(
      "INVALID_TIME",
      "A valid analysis timestamp is required."
    );
  const analyzed = analyzeSource({
    normalizedUrl: "https://provided-html.invalid/",
    finalUrl: "https://provided-html.invalid/",
    html,
    status: 200,
    contentType: "text/html; charset=utf-8",
    bytesRead: bytes.byteLength,
    declaredBytes: bytes.byteLength,
    analysisLimitBytes: MAX_INPUT_BYTES,
    truncated: false,
    redirects: 0,
    now
  });
  const expectedRules = [...RULE_IDS, ...EXCLUDED_CHECKS];
  if (analyzed.baselineActionability.modelVersion !== "source-actionability-v2.2" || analyzed.findings.length !== expectedRules.length || new Set(analyzed.findings.map((finding) => finding.ruleId)).size !== expectedRules.length || analyzed.findings.some((finding) => !expectedRules.includes(finding.ruleId))) {
    throw new PrivateRunnerError(
      "UNSUPPORTED_MODEL",
      "The source analyzer changed. Review and version the private evidence profile before continuing."
    );
  }
  const findings = analyzed.findings.filter((finding) => RULE_IDS.some((rule) => rule === finding.ruleId)).map((finding) => ({
    ruleId: finding.ruleId,
    title: safeText2(finding.title, 220),
    status: finding.status,
    severity: finding.severity,
    recommendation: finding.ruleId === "EVIDENCE_RUNTIME_BOUNDARY" ? RULE_TEXT.EVIDENCE_RUNTIME_BOUNDARY.recommendation : safeText2(finding.recommendation)
  }));
  return validateLocalReport({
    schemaVersion: REPORT_SCHEMA,
    reportKind: "provided_html",
    acquisition: "user-supplied",
    sourceScope: "provided-html-only",
    sourceSha256: createHash("sha256").update(bytes).digest("hex"),
    sourceBytes: bytes.byteLength,
    analysisLimitBytes: MAX_INPUT_BYTES,
    appId,
    analyzedAt: now.toISOString(),
    modelVersion: MODEL_VERSION,
    findingsCoverage: {
      status: "complete",
      total: findings.length,
      returned: findings.length
    },
    excludedChecks: [...EXCLUDED_CHECKS],
    findings,
    runtime: "unknown",
    limitations: [...LIMITATIONS]
  });
}
var problemRank = (finding) => finding?.status === "fail" ? 2 : finding?.status === "partial" ? 1 : 0;
function compareLocalReports(baselineInput, currentInput) {
  const baseline = validateLocalReport(baselineInput);
  const current = validateLocalReport(currentInput);
  if (baseline.appId !== current.appId || baseline.modelVersion !== current.modelVersion || baseline.schemaVersion !== current.schemaVersion || baseline.analysisLimitBytes !== current.analysisLimitBytes) {
    throw new PrivateRunnerError(
      "NOT_COMPARABLE",
      "Reports must identify the same app/page, local schema, model, and analysis limit."
    );
  }
  if (current.analyzedAt < baseline.analyzedAt)
    throw new PrivateRunnerError(
      "NOT_COMPARABLE",
      "The current report must not predate the baseline."
    );
  const previous = new Map(
    baseline.findings.map((finding) => [finding.ruleId, finding])
  );
  const changes = current.findings.flatMap((finding) => {
    const before = previous.get(finding.ruleId);
    const regressionReasons = [];
    if (problemRank(finding) > 0) {
      if (!before || problemRank(before) === 0)
        regressionReasons.push("new-problem");
      else {
        if (problemRank(finding) > problemRank(before))
          regressionReasons.push("status-worsened");
        if (SEVERITIES.indexOf(finding.severity) > SEVERITIES.indexOf(before.severity))
          regressionReasons.push("severity-increased");
      }
    }
    if (before?.status === finding.status && before.severity === finding.severity)
      return [];
    return [
      {
        ruleId: finding.ruleId,
        title: finding.title,
        before: before ? { status: before.status, severity: before.severity } : null,
        after: { status: finding.status, severity: finding.severity },
        regressed: regressionReasons.length > 0,
        regressionReasons,
        recommendation: finding.recommendation
      }
    ];
  });
  const regressionCount = changes.filter((change) => change.regressed).length;
  return {
    schemaVersion: "iswebmcp-provided-html-comparison/v1",
    sourceScope: "provided-html-only",
    inputProvenance: "user-supplied-reports-not-authenticated",
    appId: current.appId,
    modelVersion: current.modelVersion,
    analysisLimitBytes: MAX_INPUT_BYTES,
    baseline: {
      sourceSha256: baseline.sourceSha256,
      analyzedAt: baseline.analyzedAt
    },
    current: {
      sourceSha256: current.sourceSha256,
      analyzedAt: current.analyzedAt
    },
    regressed: regressionCount > 0,
    regressionCount,
    currentProblemCount: current.findings.filter(
      (finding) => problemRank(finding) > 0
    ).length,
    changes,
    noLongerReported: baseline.findings.filter(
      (finding) => !current.findings.some((item) => item.ruleId === finding.ruleId)
    ).map((finding) => finding.ruleId),
    runtime: "unknown",
    limitations: [
      "A clean comparison means no new or worsened partial/failing findings. Existing failures may remain; it is not a release safety or quality approval.",
      "Every status/severity change is shown, but pass-to-not_observed is not gated. A newly detected WebMCP hint can introduce a partial unresolved contract finding.",
      "Missing findings are never proof of a fix. This profile rejects incomplete applicable rule inventories rather than interpreting absent checks as improvements.",
      "Supplied report hashes and app IDs are declarations, not authenticated origins or verified report signatures. These reports have not been reread against the original HTML by comparison.",
      ...LIMITATIONS
    ]
  };
}

// integrations/private-runner/src/analysis.ts
import {
  isMainThread,
  parentPort,
  Worker,
  workerData
} from "node:worker_threads";
var ANALYSIS_TIMEOUT_MS = 5e3;
var ANALYSIS_HEAP_MIB = 128;
var WORKER_KIND = "iswebmcp-provided-html-analysis-v1";
async function auditIsolated(bytes, appId, timeoutMs = ANALYSIS_TIMEOUT_MS) {
  return new Promise((resolve, reject) => {
    const worker = new Worker(new URL(import.meta.url), {
      workerData: { kind: WORKER_KIND, bytes, appId },
      resourceLimits: {
        maxOldGenerationSizeMb: ANALYSIS_HEAP_MIB,
        maxYoungGenerationSizeMb: 16,
        stackSizeMb: 4
      }
    });
    let settled = false;
    const finish = async (error, report) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      try {
        await worker.terminate();
      } catch {
      }
      if (error) reject(error);
      else if (report) resolve(report);
      else
        reject(
          new PrivateRunnerError(
            "ANALYSIS_FAILED",
            "The isolated analysis did not return complete evidence."
          )
        );
    };
    const timer = setTimeout(() => {
      void finish(
        new PrivateRunnerError(
          "ANALYSIS_LIMIT",
          "Analysis exceeded its time or memory limit. No report was written; reduce the exported artifact."
        )
      );
    }, timeoutMs);
    worker.once("error", (error) => {
      const memoryLimit = "code" in error && error.code === "ERR_WORKER_OUT_OF_MEMORY";
      void finish(
        new PrivateRunnerError(
          memoryLimit ? "ANALYSIS_LIMIT" : "ANALYSIS_FAILED",
          memoryLimit ? "Analysis exceeded its time or memory limit. No report was written; reduce the exported artifact." : "The isolated analysis failed. No source content or paths are included in this error."
        )
      );
    });
    worker.once("exit", () => {
      void finish();
    });
    worker.once("message", (message) => {
      try {
        if (!message || typeof message !== "object" || !("ok" in message))
          throw new Error("invalid response");
        if (message.ok === true && "report" in message) {
          void finish(void 0, validateLocalReport(message.report));
        } else if (message.ok === false && "code" in message && "message" in message && typeof message.code === "string" && typeof message.message === "string") {
          void finish(new PrivateRunnerError(message.code, message.message));
        } else throw new Error("invalid response");
      } catch {
        void finish(
          new PrivateRunnerError(
            "ANALYSIS_FAILED",
            "The isolated analysis did not return complete evidence."
          )
        );
      }
    });
  });
}
if (!isMainThread && workerData?.kind === WORKER_KIND) {
  try {
    parentPort?.postMessage({
      ok: true,
      report: auditProvidedHtml(workerData.bytes, workerData.appId)
    });
  } catch (error) {
    parentPort?.postMessage(
      error instanceof PrivateRunnerError ? { ok: false, code: error.code, message: error.message } : {
        ok: false,
        code: "ANALYSIS_FAILED",
        message: "The isolated analysis failed. No source content or paths are included in this error."
      }
    );
  }
}

// integrations/private-runner/src/files.ts
import { constants } from "node:fs";
import * as fs from "node:fs/promises";
import path from "node:path";
function fileError(error) {
  if (error instanceof PrivateRunnerError) return error;
  const code = typeof error === "object" && error !== null && "code" in error ? error.code : void 0;
  if (code === "EEXIST")
    return new PrivateRunnerError(
      "OUTPUT_EXISTS",
      "Output already exists. Choose a new file; existing files are never overwritten."
    );
  if (code === "ENOENT")
    return new PrivateRunnerError(
      "FILE_NOT_FOUND",
      "An input file or output directory does not exist."
    );
  if (code === "EACCES" || code === "EPERM")
    return new PrivateRunnerError(
      "FILE_ACCESS_DENIED",
      "File access was denied. Check permissions without sharing sensitive paths."
    );
  return new PrivateRunnerError(
    "FILE_IO_ERROR",
    "A local file operation failed. No filesystem path is included in this error."
  );
}
function sameIdentity(left, right) {
  const sameDevice = left.dev === right.dev || process.platform === "win32" && (left.dev === BigInt(0) || right.dev === BigInt(0));
  return sameDevice && left.ino === right.ino && left.isFile() && right.isFile();
}
function unchanged(left, right) {
  return sameIdentity(left, right) && left.size === right.size && left.mtimeNs === right.mtimeNs && left.ctimeNs === right.ctimeNs;
}
function resolvedLocalPath(filePath) {
  if (!filePath || filePath.includes("\0") || /^[a-z][a-z\d+.-]*:\/\//i.test(filePath))
    throw new PrivateRunnerError(
      "INVALID_PATH",
      "Provide a local filesystem path, not a URL."
    );
  if (/^(?:\\\\|\/\/|\\\?\?\\)/.test(filePath))
    throw new PrivateRunnerError(
      "INVALID_PATH",
      "UNC, network-share, and device paths are not supported. Use a trusted local disk."
    );
  const resolved = path.resolve(filePath);
  if (/^(?:\\\\|\/\/)/.test(resolved))
    throw new PrivateRunnerError(
      "INVALID_PATH",
      "The working directory must be on a trusted local disk."
    );
  if (resolved.slice(path.parse(resolved).root.length).includes(":"))
    throw new PrivateRunnerError(
      "INVALID_PATH",
      "Alternate data streams are not supported."
    );
  return resolved;
}
async function noSymlinkComponents(target, operations, includeLeaf = true) {
  let cursor = includeLeaf ? target : path.dirname(target);
  for (; ; ) {
    const info = await operations.lstat(cursor, { bigint: true });
    if (info.isSymbolicLink())
      throw new PrivateRunnerError(
        "SYMLINK_REFUSED",
        "Symlink or junction paths are not supported. Use a regular file in a trusted directory."
      );
    if (cursor !== target && !info.isDirectory())
      throw new PrivateRunnerError(
        "INVALID_PATH",
        "A parent path is not a directory."
      );
    const parent = path.dirname(cursor);
    if (parent === cursor) break;
    cursor = parent;
  }
}
async function readBoundedFile(filePath, operations = fs) {
  let handle;
  let result;
  let failure;
  try {
    const target = resolvedLocalPath(filePath);
    await noSymlinkComponents(target, operations);
    const before = await operations.lstat(target, { bigint: true });
    if (!before.isFile() || before.isSymbolicLink())
      throw new PrivateRunnerError(
        "NOT_REGULAR_FILE",
        "Input must be a regular file, not a directory, device, pipe, or link."
      );
    if (before.size < BigInt(1) || before.size > BigInt(MAX_INPUT_BYTES))
      throw new PrivateRunnerError(
        "INVALID_SIZE",
        "Provide a nonempty regular file no larger than 2 MiB."
      );
    handle = await operations.open(
      target,
      constants.O_RDONLY | (constants.O_NOFOLLOW ?? 0) | (constants.O_NONBLOCK ?? 0)
    );
    const opened = await handle.stat({ bigint: true });
    if (!unchanged(before, opened))
      throw new PrivateRunnerError(
        "FILE_CHANGED",
        "Input changed while opening. Export a stable copy and retry."
      );
    const buffer = Buffer.alloc(Number(opened.size) + 1);
    let offset = 0;
    while (offset < buffer.length) {
      const { bytesRead } = await handle.read(
        buffer,
        offset,
        buffer.length - offset,
        offset
      );
      if (bytesRead === 0) break;
      offset += bytesRead;
    }
    const after = await handle.stat({ bigint: true });
    await noSymlinkComponents(target, operations);
    const named = await operations.lstat(target, { bigint: true });
    if (offset !== Number(opened.size) || !unchanged(opened, after) || !unchanged(opened, named))
      throw new PrivateRunnerError(
        "FILE_CHANGED",
        "Input changed during reading. Export a stable copy and retry."
      );
    result = buffer.subarray(0, offset);
  } catch (error) {
    failure = fileError(error);
  } finally {
    try {
      await handle?.close();
    } catch (error) {
      failure ??= fileError(error);
    }
  }
  if (failure) throw failure;
  if (!result)
    throw new PrivateRunnerError(
      "FILE_IO_ERROR",
      "The local read did not return complete bytes."
    );
  return result;
}
async function writeExclusiveJson(filePath, value, operations = fs) {
  let handle;
  let failure;
  try {
    const text = `${JSON.stringify(value, null, 2)}
`;
    if (Buffer.byteLength(text) > MAX_INPUT_BYTES)
      throw new PrivateRunnerError(
        "OUTPUT_TOO_LARGE",
        "Output exceeds the private artifact limit."
      );
    const target = resolvedLocalPath(filePath);
    await noSymlinkComponents(target, operations, false);
    handle = await operations.open(
      target,
      constants.O_WRONLY | constants.O_CREAT | constants.O_EXCL | (constants.O_NOFOLLOW ?? 0),
      384
    );
    const opened = await handle.stat({ bigint: true });
    if (!opened.isFile())
      throw new PrivateRunnerError(
        "NOT_REGULAR_FILE",
        "Output must be a new regular file."
      );
    await noSymlinkComponents(target, operations);
    if (!sameIdentity(opened, await operations.lstat(target, { bigint: true })))
      throw new PrivateRunnerError(
        "FILE_CHANGED",
        "Output identity changed. Do not trust the incomplete output."
      );
    await handle.writeFile(text, { encoding: "utf8" });
    await handle.sync();
    await noSymlinkComponents(target, operations);
    if (!sameIdentity(opened, await operations.lstat(target, { bigint: true })))
      throw new PrivateRunnerError(
        "FILE_CHANGED",
        "Output identity changed. Do not trust the incomplete output."
      );
  } catch (error) {
    failure = fileError(error);
  } finally {
    try {
      await handle?.close();
    } catch (error) {
      failure ??= fileError(error);
    }
  }
  if (failure) throw failure;
}

// integrations/private-runner/src/cli.ts
var HELP = `isWebMCP offline checker ${VERSION} (developer preview)

Usage:
  node iswebmcp-offline.mjs audit <local-export.html> --app <app-page-id> --output <report.json>
  node iswebmcp-offline.mjs compare <baseline.json> <current.json> --output <comparison.json>
  node iswebmcp-offline.mjs --help
  node examples/run-demo.mjs

Node 22.13+ required. Files must be regular, valid UTF-8, nonempty, and <= 2 MiB.
Analysis uses a disposable worker: 5-second deadline, 128 MiB old-generation heap.
Choose a non-sensitive, stable app/page ID. Use trusted local directories, not links.
Outputs are new files only (mode 0600 where supported); nothing is overwritten.
No application network calls, HTML execution, browser authentication, or analytics.
UNC/device/URL paths are refused. Use trusted local disks: mapped/synced filesystems
are outside this guarantee. Use OS-level egress denial for network isolation.
No source HTML, file paths, page URLs, or goals are included in default reports.
Exported HTML is user-supplied evidence, not a complete-page or runtime verification.

Exit codes: 0 = audit completed / no new or worsened comparison findings;
            1 = comparison reports new or worsened partial/failing findings;
            2 = invalid input, incompatible/inconclusive evidence, or IO failure.
Existing failures may remain when comparison exits 0. Scores are not release gates.
`;
function options(args, expected) {
  if (args.length !== expected.length * 2)
    throw new PrivateRunnerError(
      "USAGE",
      "Use --help for the exact command syntax."
    );
  const values = /* @__PURE__ */ Object.create(null);
  for (let index = 0; index < args.length; index += 2) {
    const key = args[index];
    const value = args[index + 1];
    if (!expected.includes(key) || Object.hasOwn(values, key) || !value || value.startsWith("--"))
      throw new PrivateRunnerError(
        "USAGE",
        "Unknown, duplicate, or missing option. Use --help."
      );
    values[key] = value;
  }
  return values;
}
async function runCli(args, output = {
  stdout: (text) => process.stdout.write(text),
  stderr: (text) => process.stderr.write(text)
}) {
  try {
    const [major, minor] = process.versions.node.split(".").map(Number);
    if (major < 22 || major === 22 && minor < 13)
      throw new PrivateRunnerError(
        "UNSUPPORTED_NODE",
        "Node 22.13 or later is required."
      );
    if (args.length === 1 && args[0] === "--help") {
      output.stdout(HELP);
      return 0;
    }
    if (args[0] === "audit" && args[1] && !args[1].startsWith("--")) {
      const flags = options(args.slice(2), ["--app", "--output"]);
      const report = await auditIsolated(
        await readBoundedFile(args[1]),
        flags["--app"]
      );
      await writeExclusiveJson(flags["--output"], report);
      output.stdout(
        "Audit completed: provided-HTML findings saved locally. Runtime remains unknown.\n"
      );
      return 0;
    }
    if (args[0] === "compare" && args[1] && args[2] && !args[1].startsWith("--") && !args[2].startsWith("--")) {
      const flags = options(args.slice(3), ["--output"]);
      const baseline = parseReportJson(await readBoundedFile(args[1]));
      const current = parseReportJson(await readBoundedFile(args[2]));
      const comparison = compareLocalReports(baseline, current);
      await writeExclusiveJson(flags["--output"], comparison);
      output.stdout(
        `Comparison saved locally: ${comparison.regressionCount} new or worsened finding(s); ${comparison.currentProblemCount} current partial/failing finding(s). Runtime remains unknown.
`
      );
      return comparison.regressed ? 1 : 0;
    }
    throw new PrivateRunnerError(
      "USAGE",
      "Use --help for the exact command syntax."
    );
  } catch (error) {
    const message = error instanceof PrivateRunnerError ? `ERROR [${safeText2(error.code, 50)}]: ${safeText2(error.message)}` : "ERROR [INTERNAL]: The local operation failed. No source content or file paths are included in this error.";
    output.stderr(`${message}
`);
    return 2;
  }
}
if (isMainThread2 && process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  void runCli(process.argv.slice(2)).then((code) => {
    process.exitCode = code;
  });
}
export {
  HELP,
  runCli
};
